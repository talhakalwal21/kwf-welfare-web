/* PUBLIC browser configuration only. Never put service_role or database passwords here. */
window.KWF_CONFIG = Object.freeze({
  supabaseUrl: '',
  supabasePublishableKey: '',
  foundationName: 'Kalwal Welfare Foundation'
});
